/* Title: A4 - Ausgabe der Uhrzeit mit perfamenter Aktualisierung
Autor: Volkan Demir. 09.05.2024
Desc: Message-Element wird mit dem Datum gefüllt.
      Diese wird dann mittels HTML ausgegeben
*/

var info = new Vue({
    el: '#info',
    data: {
        message: new Date()
        // Es wird ein message-Objekt (Variable) angelegt
        // Aktuell ist die Variable aber nicht belegt, sprich ist leer
    }
});
