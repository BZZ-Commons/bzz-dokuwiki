let personen = [];

// Daten laden
fetch("data.json")
  .then(res => res.json())
  .then(data => {
    personen = data;
    renderListe(personen);
  })
  .catch(err => {
    console.error("Fehler beim Laden der JSON:", err);
  });

// Liste anzeigen
function renderListe(liste) {
  const ausgabe = document.getElementById("ausgabe");

  if (liste.length === 0) {
    ausgabe.innerHTML = "Keine Eintraege gefunden";
    return;
  }

  let html = "<table><tr><th>Vorname</th><th>Name</th><th>Hobby</th></tr>";

  for (let i = 0; i < liste.length; i++) {
    const p = liste[i];

    html += `<tr>
      <td>${p.vorname}</td>
      <td>${p.name}</td>
      <td>${p.hobby}</td>
    </tr>`;
  }

  html += "</table>";
  ausgabe.innerHTML = html;
}


// Filter
document.getElementById("filterForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.toLowerCase();

  const hobbyCheckboxen = document.querySelectorAll('input[name="hobby"]:checked');
  const ausgewaehlteHobbies = [];

  for (let i = 0; i < hobbyCheckboxen.length; i++) {
    ausgewaehlteHobbies.push(hobbyCheckboxen[i].value.toLowerCase());
  }

  const gefiltert = personen.filter(function (p) {
    const vollerName = (p.vorname + " " + p.name).toLowerCase();
    const hobby = p.hobby.toLowerCase();

    const namePasst = vollerName.includes(name);

    let hobbyPasst = false;

    if (ausgewaehlteHobbies.length === 0) {
      hobbyPasst = true;
    } else {
      for (let i = 0; i < ausgewaehlteHobbies.length; i++) {
        if (hobby === ausgewaehlteHobbies[i]) {
          hobbyPasst = true;
        }
      }
    }

    return namePasst && hobbyPasst;
  });

  renderListe(gefiltert);
});


// Reset
document.getElementById("resetBtn").addEventListener("click", function () {
  document.getElementById("name").value = "";

  const hobbyCheckboxen = document.querySelectorAll('input[name="hobby"]');

  for (let i = 0; i < hobbyCheckboxen.length; i++) {
    hobbyCheckboxen[i].checked = false;
  }

  renderListe(personen);
});