/* ********************************************************************** */
/* Author: Volkan.demir@bzz.ch, 09.02.26                                  */
/* Desc: LU01_l01: myAlgebraCalculator.js                                 */
/* ********************************************************************** */

console.clear();

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: devide (zahl1, zahl2)                                            */
/* Desc: Return the quotient of two numbers. Z2 must not be 0             */
/* ********************************************************************** */
zahl1 = 20, zahl2 = 10;
function geteilt(zahl1, zahl2) {

    if (zahl2 == 0) {
        console.log("z2 must not be 0");
    }
    else {

        return zahl1/zahl2;
    }
 }   

 
console.log("Teilauftrag 4 - geteilt(" + zahl1 + ", " + zahl2 + ") = " + geteilt(zahl1, zahl2));
