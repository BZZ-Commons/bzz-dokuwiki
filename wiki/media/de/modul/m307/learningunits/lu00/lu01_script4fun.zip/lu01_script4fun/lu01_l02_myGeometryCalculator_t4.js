const pi = 3.14; //accuracy is sufficient enough for our purpose
 var sA=3, sB=10, sC=5;

console.log("function triangleCircumfence with sideA:", sA, ", sideB:", sB, 
    " sC:", sC, "=",triangleCircumfence(sA, sB, sC));
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: triangleCircumfence (sideA, sideB, sideC)                        */
/* Desc: Returns the triangleCircumfence to three given side length       */
/* ********************************************************************** */
function triangleCircumfence(sideA, sideB, sideC) {
    let cf = sideA+sideB+sideC; // lokale Variable, nur innerhalb Funktion sichtbar
    return cf;
}
