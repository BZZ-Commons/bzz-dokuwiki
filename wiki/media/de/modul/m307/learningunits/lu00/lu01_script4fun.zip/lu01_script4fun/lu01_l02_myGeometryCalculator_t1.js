const pi = 3.14; //accuracy is sufficient enough for our purpose
let r = 10; // 10 is a easy number, since easy to calculate

console.clear();

console.log("function circleArea mit Radius: ", r, " = ", circleArea(r), "Flaecheneinheiten.");
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: circleArea (radius)                                              */
/* Desc: Returns the area of a circle to a given radius                   */
/* ********************************************************************** */
function circleArea(radius) {
    let cA = pi*radius*radius; 
    return cA;
}
