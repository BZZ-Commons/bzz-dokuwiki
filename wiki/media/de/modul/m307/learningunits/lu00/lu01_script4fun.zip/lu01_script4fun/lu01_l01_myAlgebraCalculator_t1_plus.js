/* ********************************************************************** */
/* Author: Volkan.demir@bzz.ch, 09.02.26                                  */
/* Desc: LU01_l01: myAlgebraCalculator.js                                 */
/* ********************************************************************** */

console.clear();

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: plus (zahl1, zahl2)                                              */
/* Desc: Return the sum of two numbers                                    */
/* ********************************************************************** */

let zahl1 = 22, zahl2 = 44;

function plus(x, y) {
    return x+y;
}

console.log(plus(zahl1, zahl2));
console.log ("Teilauftrag 1 - plus(" + zahl1 + ", " + zahl2 + ") = " + plus(zahl1, zahl2));
