/* ********************************************************************** */
/* Author: Volkan.demir@bzz.ch, 09.02.26                                  */
/* Desc: LU01_l01: myAlgebraCalculator.js                                 */
/* ********************************************************************** */

console.clear();

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: minus (zahl1, zahl2)                                             */
/* Desc: Return the quadrat of a number                                   */
/* ********************************************************************** */
zahl1 = 20;
function quadrat(zahl1) {
       return zahl1*zahl1;
}
console.log("Teilauftrag 5 - quadrat(" + zahl1 + ") = " + quadrat(zahl1));
