var unsortedArrayV1 = [3, 55, 2, 8, 33, 199, 120, 100, 999, 53, 44, 54, 67, 22, 0]; // unsorted array of numbers
let swapCnt = 0; // count of the necessary swap due to the wrong order of the numbers
let loopCnt = 0;

console.clear();

console.log("array bubbleSortV1 - Vorher: ", unsortedArrayV1);
console.log("function bubbleSortV1 - Nachher: " + bubbleSortV1(unsortedArrayV1));

function bubbleSortV1(myUnsArray) {
    let arrLen = myUnsArray.length;
    let myLocArray=myUnsArray;

    for (var i=0; i<=arrLen; i++) {

        for (var j=0; j<arrLen; j++) {
                    loopCnt++;
            if (myLocArray[j]>myLocArray[j+1]) { // ascending = <; descending = >
                swapCnt++; // count swap
                let tmp=myLocArray[j]; // change of two values of variables
                myLocArray[j]=myLocArray[j+1];
                myLocArray[j+1]=tmp;
            }
        }
    }
    return myLocArray;
}
console.log("loopCnt: "+loopCnt);
console.log("swapCnt: "+swapCnt);

