const pi = 3.14; //accuracy is sufficient enough for our purpose
var s=3, h=10;

console.log("function triangleArea with side ", s, " & height ", h, "=", triangleArea(s, h));
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: triangleArea (side, height)                                      */
/* Desc: Returns the triangleArea to side and height                      */
/* ********************************************************************** */
function triangleArea(side, height) {
    let area = side*height/2; // Lokale Variable ist nur sichtbar innerhalb der Funktion
    return area;
}
