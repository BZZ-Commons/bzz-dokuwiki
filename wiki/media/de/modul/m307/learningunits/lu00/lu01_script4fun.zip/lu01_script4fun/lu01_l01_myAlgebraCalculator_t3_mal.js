/* ********************************************************************** */
/* Author: Volkan.demir@bzz.ch, 09.02.26                                  */
/* Desc: LU01_l01: myAlgebraCalculator.js                                 */
/* ********************************************************************** */

console.clear();

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: mal (zahl1, zahl2)                                               */
/* Desc: Return the product of two numbers.                               */
/* ********************************************************************** */
zahl1 = 20, zahl2 = 5;
function mal(zahl1, zahl2) {
        return zahl1 * zahl2;
}
console.log("Teilauftrag 3 - mal(" + zahl1 + ", " + zahl2 + ") = " + mal(zahl1, zahl2));
