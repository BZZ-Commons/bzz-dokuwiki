var unsortedArrayV1 = [3, 55, 2, 8, 33, 199, 120, 100, 999, 53, 44, 54, 67, 22, 0]; // unsorted array of numbers
console.clear();

console.log("array bubbleSortV1 - Vorher: ", unsortedArrayV1);
console.log("function bubbleSortV1 - Nachher: " + bubbleSortV1(unsortedArrayV1));


/* ************************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                      */
/* Call: bubbleSortV1 (array)                                                 */
/* Desc: Returns the array in a ascending or descending order.                */
/*       The algorithm is not smart as it uses 2 for-loops with fixe range.   */
/* ************************************************************************** */
function bubbleSortV1(myUnsArray) {
    let arrLen = myUnsArray.length;
    let myLocArray=myUnsArray;
    let swapCnt = 0; // count of the necessary swap due to the wrong order of the numbers
    let loopCnt = 0; // count of the necessary swap due to the wrong order of the numbers

    for (var i=0; i<=arrLen; i++) {
        for (var j=0; j<arrLen; j++) {
            loopCnt++;
            if (myLocArray[j]>myLocArray[j+1]) { // ascending = <; descending = >
                swapCnt++; // count swap
              //  console.log("swap1:"+swapCnt);
                var tmp=myLocArray[j]; // change of two values of variables
                myLocArray[j]=myLocArray[j+1];
                myLocArray[j+1]=tmp;
            }
        }
    }
    console.log("loopCnt: "+loopCnt);
    console.log("swapCnt: "+swapCnt);
    return myLocArray;
}
