const pi = 3.14; //accuracy is sufficient enough for our purpose
var sideA = 10, sideB=15;

console.log("function rectangleArea: sideA:", sideA, " sideB:", sideB, " = ", 
    rectangleArea(sideA, sideB));
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: rectangleArea(side)                                              */
/* Desc: Return the rectangleArea to given sideS and sideB                */
/* ********************************************************************** */
function rectangleArea(sA, sB) {
    let rA = sA*sB;
    return rA;
}
