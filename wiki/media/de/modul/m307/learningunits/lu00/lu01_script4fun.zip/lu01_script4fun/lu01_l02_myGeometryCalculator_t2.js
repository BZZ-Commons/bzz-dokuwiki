const pi = 3.14; //accuracy is sufficient enough for our purpose
var r = 10; // 10 is a easy number, since easy to calculate

console.log("function circleCircumference: " + r + " = " + circleCircumference(r));
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: circleCircumference (radius)                                     */
/* Desc: Returns the circumference of a circle to a given radius          */
/* ********************************************************************** */
function circleCircumference(radius) {
    return 2*pi*radius;
}
