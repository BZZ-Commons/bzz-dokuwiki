/* ********************************************************************** */
/* Author: Volkan.demir@bzz.ch, 09.02.26                                  */
/* Desc: LU01_l01: myAlgebraCalculator.js                                 */
/* ********************************************************************** */

console.clear();

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: potenF (zahl1, zahl2)                                            */
/* Desc: Return the quitient of two numbers. Basad on a for-loop          */
/* ********************************************************************** */
var base = 5, exponent=4;

function potenzF(base, exponent) {
    var result = 1; // initializing result with neutral element of multiplication
    for (var i=1; i<=exponent; i++) { // same as i=i+1
        result *= base; // same as result = result * base
    }
    return result;
}
console.log("Teilauftrag 7 - potenzF(" + base + ", " + exponent + ") = " + potenzF(base, exponent));

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: potenW (zahl1, zahl2)                                            */
/* Desc: Return the quitient of two numbers. Basad on a whilw-loop          */
/* ********************************************************************** */

function potenzW(base, exponent) {
    var result = 1; // initializing result with neutral element of multiplication
    let i= 1;
    while (i<=exponent) { // same as i=i+1
        result *= base; // same as result = result * base
        i++;
    }
    return result;
}

console.log("Teilauftrag 7 - potenzW(" + base + ", " + exponent + ") = " + potenzW(base, exponent));


