/* ********************************************************************** */
/* Author: Volkan.demir@bzz.ch, 09.02.26                                  */
/* Desc: LU01_l01: myAlgebraCalculator.js                                 */
/* ********************************************************************** */

console.clear();

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: wurzel (zahl1)                                             */
/* Desc: Return the square root of a number                                   */
/* ********************************************************************** */
zahl1 = 625;
function wurzel(zahl1) {
   return Math.sqrt(zahl1);    
}
console.log("Teilauftrag 6 - wurzel(" + zahl1 + ") = " + wurzel(zahl1));
