const pi = 3.14; //accuracy is sufficient enough for our purpose

var side = 4;
console.log("function squareCircumference: side ", side +" = ",squareCircumference (side));
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: squareCircumference(side)                                        */
/* Desc: Return the squareCircumference a given side                      */
/* ********************************************************************** */
function squareCircumference(s) {
    let cf = 4*s; // lokale Variablen
    return cf;
}