// dies ist die Realisierung der Fakultät-Funktion
let zahl = 5; // --> 1 * 2 * 3 * 4 * 5 = 120

function fakultaet(zahl) {
    let result = 1; 
    for (let i=1; i<=zahl; i++) {   
        result = result * i; // result *= i;
    
    }
    return result;
}   
console.log("Fakultät von ", zahl, " ist: ", fakultaet(zahl));

function fakultaet2(zahl) {
    let result = 1; 
    for (let i=zahl; i>=1; i--) {   
        result = result * i; // result *= i;
    
    }
    return result;
}  
console.log("Fakultät2 von ", zahl, " ist: ", fakultaet2(zahl));