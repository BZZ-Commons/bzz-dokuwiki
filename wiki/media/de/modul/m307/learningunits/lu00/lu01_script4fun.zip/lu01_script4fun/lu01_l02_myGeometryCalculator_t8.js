const pi = 3.14; //accuracy is sufficient enough for our purpose

var sideA = 10, sideB=15;
console.log("function rectangleCurcumfence: sideA:", sideA, " sideB:", sideB, 
    " = ", rectangleCurcumference(sideA, sideB));
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: rectangleCurcumference(side)                                     */
/* Desc: Return the rectangleCurcumference to a given sideS and sideB     */
/* ********************************************************************** */
function rectangleCurcumference(sA, sB) {
    let rcf = 2*(sA+sB); 
    return rcf;
}

