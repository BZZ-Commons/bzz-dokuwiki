var unsortedArrayV1 = [3, 55, 2, 8, 33, 199, 120, 100, 999, 53, 44, 54, 67, 22, 0]; // unsorted array of numbers

console.clear();
console.log("function bubbleSortV1: " + bubbleSortV1(unsortedArrayV1));
/* ************************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                      */
/* Call: bubbleSortV1 (array)                                                 */
/* Desc: Returns the array in a ascending or descending order.                */
/*       The algorithm is not smart, since it uses 2 for-loops with fixe rage.*/
/* ************************************************************************** */
function bubbleSortV1(myUnsArray) {
    var arrLen = myUnsArray.length;
    var myLocArray=myUnsArray;
    var swapCnt = 0; // count of the necessary swap due to the wrong order of the numbers
    var loopCnt = 0; // count of the necessary swap due to the wrong order of the numbers

    for (var i=0; i<arrLen; i++) {
        for (var j=0; j<arrLen; j++) {
            loopCnt++;
            if (myLocArray[j]>myLocArray[j+1]) { // ascending = <; descending = >
                swapCnt++; // count swap
              //  console.log("swap1:"+swapCnt);
                var tmp=myLocArray[j]; // change of two values of variables
                myLocArray[j]=myLocArray[j+1];
                myLocArray[j+1]=tmp;
            }
        }
    }
    myLocArray.push(loopCnt) // Adding the swap at the end of the array
    myLocArray.push(swapCnt) // Adding the swap at the end of the array
    return myLocArray;
}


var unsortedArrayV2 = [3, 55, 2, 8, 33, 199, 120, 100, 999, 53, 44, 54, 67, 22, 0]; // unsorted array of numbers
console.log("function bubbleSortV2: " + bubbleSortV2(unsortedArrayV2));
/* ************************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                      */
/* Call: bubbleSortV1 (array)                                                 */
/* Desc: Returns the array in a ascending or descending order.                */
/*       The algorithm is smart, it knows, when sorting is finished.          */
/* ************************************************************************** */
function bubbleSortV2(myUnsArray) {
    let arrLen = myUnsArray.length;
    let myLocArray=myUnsArray;
    let finished=false; //flag decides whether another loop or not
    var swapCnt = 0; // count of the necessary swap due to the wrong order of the numbers
    var loopCnt = 0;

    while (!finished) {
   
        finished = true; // reset of the finished-flag
        for (var i=0; i<arrLen; i++) {
            loopCnt++
            if (myLocArray[i]>myLocArray[i+1]) { // ascending = <; descending = >
                swapCnt++; // count swap
                finished=false; // have to loop another time
               // console.log("swap2:"+swapCnt);

                var tmp=myLocArray[i]; // change of two values of variables
                myLocArray[i]=myLocArray[i+1];
                myLocArray[i+1]=tmp;
            }
            //console.log(myLocArray);
        }
    }
    myLocArray.push(loopCnt) // Adding the swap at the end of the array
    myLocArray.push(swapCnt) // Adding the swap at the end of the array
    return myLocArray;
}



