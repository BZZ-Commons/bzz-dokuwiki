const pi = 3.14; //accuracy is sufficient enough for our purpose
var side = 20;

console.log("function square: ", side, " = "+squareArea(side));
/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 02.03.23                                  */
/* Call: squareArea (side)                                                */
/* Desc: Returns the area of a square                                     */
/* ********************************************************************** */
function squareArea(x) {
    let sa = x*x;
    return sa;
}
