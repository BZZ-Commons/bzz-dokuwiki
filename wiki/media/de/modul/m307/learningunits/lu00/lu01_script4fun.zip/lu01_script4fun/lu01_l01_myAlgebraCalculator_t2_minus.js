/* ********************************************************************** */
/* Author: Volkan.demir@bzz.ch, 09.02.26                                  */
/* Desc: LU01_l01: myAlgebraCalculator.js                                 */
/* ********************************************************************** */

console.clear();

/* ********************************************************************** */
/* Author: volkan.demir@bzz.ch, 09.02.26                                  */
/* Call: minus (zahl1, zahl2)                                             */
/* Desc: Return the difference of two numbers. Z1 must be larger than z2  */
/* ********************************************************************** */
zahl1 = 45, zahl2 = 22;
function minus(minuend, subtrahend) {
    if (minuend>subtrahend) {
        return minuend-subtrahend;
    }
    else {
        console.log("z1 muss grösser als z2 sein");
        // to avoid negativ numbers z1 must be larger than z2
    }
}
console.log ("Teilauftrag 2 - minus(" + zahl1 + ", " + zahl2 + ") = " + minus(zahl1, zahl2));
