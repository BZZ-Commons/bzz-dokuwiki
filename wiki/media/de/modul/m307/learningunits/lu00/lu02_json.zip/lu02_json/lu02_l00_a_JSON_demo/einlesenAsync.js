const fs = require("fs");

// Asynchrones Einlesen
fs.readFile("person.json", "utf8", (err, data) => {
  if (err) {
    console.error("Fehler beim Lesen:", err);
    return;
  }

  // JSON umwandeln
  const daten = JSON.parse( data);

  console.log("TypeOf:",typeof daten); // object
  console.log(daten);

  console.log("Name:", daten.name);
  console.log("Alter:", daten.alter);
  console.log("Aktiv:", daten.ist_aktiv);

  console.log("Hobbys:");
  daten.hobbys.forEach(hobby => console.log(" -", hobby));

  console.log("Adresse:");
  console.log("  Stadt:", daten.adresse.stadt);
  console.log("  Strasse:", daten.adresse.strasse);
  console.log("  PLZ:", daten.adresse.plz);
});
