const fs = require("fs");

fs.readFile("lernende.json", "utf8", (err, data) => {
  if (err) {
    console.error("Fehler beim Lesen:", err);
    return;
  }

  const daten = JSON.parse(data);

  console.clear();

  console.log("Typ von daten:", typeof daten); // object

  console.log("Anzahl Lernende:", daten.lernende.length);

  console.log("\n--- Gesamte Daten als formatierter JSON-String ---");
  console.log(JSON.stringify(daten, null, 2));  //  formatierte Ausgabe

  console.log("\n--- Einzelwerte erster Datensatz ---");
  console.log("Name:",     daten.lernende[0].name);
  console.log("Nachname:", daten.lernende[0].nachname);
  console.log("Alter:",    daten.lernende[0].alter);
  console.log("BMS:",      daten.lernende[0].bms);
  console.log("Hobbies:",  daten.lernende[0].hobbies[0], daten.lernende[0].hobbies[1], daten.lernende[].hobbies[2]);

  console.log("\n--- Einzelwerte zweiter Datensatz ---");
  console.log("Name:", daten.lernende[1].name);
  console.log("Nachname:", daten.lernende[1].nachname);
  console.log("Alter:", daten.lernende[1].alter);
  console.log("BMS:", daten.lernende[1].bms);
  console.log("Hobbies:", daten.lernende[1].hobbies[0], daten.lernende[0].hobbies[1], daten.lernende[1].hobbies[2]);
 
});


  