// Author: Volkan Demir, 17.03.26
// LU01.a03: Vorlage für die Aufgabe. Aktuell statische Ausgabe von JSON-Daten
// Ziel: Dynamischer Ausgabe von JSON-Daten mittels einer Schleife


  const fs = require("fs");
  //
  fs.readFile("lernende.json", "utf8", (err, data) => {
    if (err) {
      console.error("Fehler beim Lesen:", err);
      return;
    }
    //
    const daten = JSON.parse(data);
    //
    console.log(typeof daten); // object
    //
    console.log("Anzahl Lernende:", daten.lernende.length);
    //
    console.log("\n--- Gesamte Daten als formatierter JSON-String ---");
    console.log(JSON.stringify(daten, null, 2));  //  unformatierte Ausgabe

    console.log("\n--- Einzelwerte erster Datensatz ---");
    // Hier muss die äussere Schleife eingebaut werde, die den Index der Lernenden enthält

    console.log("Name:", daten.lernende[0].name);
    console.log("Nachname:", daten.lernende[0].nachname);
    console.log("Alter:", daten.lernende[0].alter);
    console.log("BMS:", daten.lernende[0].bms);
    // hier kommt die innere Schleife für die Hobbies
    console.log("Hobbies:", daten.lernende[0].hobbies[0], daten.lernende[0].hobbies[1], daten.lernende[1].hobbies[2]);
  });


  
    