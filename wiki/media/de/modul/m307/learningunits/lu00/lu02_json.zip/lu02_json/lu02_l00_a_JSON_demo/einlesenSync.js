const fs = require("fs"); // nicht vergessen

// Datei einlesen
const jsonText = fs.readFileSync("person.json", "utf8");

// In Objekt umwandeln
const daten = JSON.parse(jsonText);

console.log(typeof daten); // object
console.log(daten);

// Einzelfelder ausgeben
console.log("Name:", daten.name);
console.log("Alter:", daten.alter);
console.log("Aktiv:", daten.ist_aktiv);

// Hobbys
console.log("Hobbys:");
daten.hobbys.forEach(hobby => console.log(" -", hobby));

// Adresse
console.log("Adresse:");
console.log("  Stadt:", daten.adresse.stadt);
console.log("  PLZ:", daten.adresse.plz);
