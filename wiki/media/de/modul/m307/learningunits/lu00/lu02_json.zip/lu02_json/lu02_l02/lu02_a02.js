const fs = require("fs");

fs.readFile("lernende.json", "utf8", (err, data) => {
  if (err) {
    console.error("Fehler beim Lesen:", err);
    return;
  }

  const daten = JSON.parse(data);

  console.log(typeof daten); // object

  console.log("Anzahl Lernende:", daten.lernende.length);


  console.log("\n--- Gesamte Daten als formatierter JSON-String ---");
  console.log(JSON.stringify(daten, null, 2));  // << formatierte Ausgabe

  console.log("\n--- Einzelwerte erster Datensatz ---");
  console.log("Name:", daten.lernende[0].name);
  // hier müssen die restlichen Attribute des ersten Datensatzes ausgegeben werden
  // das erste Atttribut ist bereits als vorlage vorhanden
  
  console.log("\n--- Einzelwerte zweiter Datensatz ---");
  // hier muss, nach Vorlage des ersten Satzes, der zweite Satz ebenfalls ausgeben werden.
  //   
});


  