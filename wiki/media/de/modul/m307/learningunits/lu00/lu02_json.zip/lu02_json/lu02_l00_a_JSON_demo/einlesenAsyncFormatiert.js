const fs = require("fs");

fs.readFile("person.json", "utf8", (err, data) => {
  if (err) {
    console.error("Fehler beim Lesen:", err);
    return;
  }

  const daten = JSON.parse(data);

  console.log(typeof daten); // object

  console.log("\n--- Gesamte Daten als formatierter JSON-String ---");
  console.log(JSON.stringify(daten, null, 2));  // << formatierte Ausgabe

  console.log("\n--- Einzelwerte ---");
  console.log("Name:", daten.name);
  console.log("Alter:", daten.alter);
  console.log("Aktiv:", daten.ist_aktiv);

  console.log("\nHobbys:");
  daten.hobbys.forEach(hobby => console.log(" -", hobby));

  console.log("\nAdresse:");
  console.log("  Stadt:", daten.adresse.stadt);
  console.log("  PLZ:", daten.adresse.plz);
});
