// Author: Volkan Demir, 17.03.26
// LU01.l03: Dynamischer Ausgabe von JSON-Daten mittels einer Schleife


const fs = require("fs");

// JSON asynchron einlesen
fs.readFile("lernende2.json", "utf8", (err, data) => {
  if (err) {
    console.error("Fehler beim Lesen:", err);
    return;
  }

  const daten = JSON.parse(data);

  console.log("\n--- Ausgabe aller Lernenden (mit for-Schleifen) ---\n");

  // ÄUSSERE FOR-SCHLEIFE → alle Lernenden durchgehen
  for (let i = 0; i < daten.lernende.length; i++) {
    console.log("Alter:", daten.lernende[i].alter);
    console.log("StudentenID:", i);
    console.log("Name:", daten.lernende[i].name, daten.lernende[i].nachname);

 
    console.log("BMS:", daten.lernende[i].bms);
    // INNERE FOR-SCHLEIFE → Hobbys ausgeben
    console.log("Hobbys:");

    for (let j = 0; j < daten.lernende[i].hobbies.length; j++) {
      console.log(" -", daten.lernende[i].hobbies[j]);
    }

    console.log("\n--- Hobbys rückwärts ---");
     for (let k= daten.lernende[i].hobbies.length - 1; k>= 0; k-- ) {
      console.log(" -", daten.lernende[i].hobbies[k]  );
    }

 
    
    console.log(); // Leerzeile für Übersicht
  }
});
