const buttons = document.querySelectorAll('.accordion-btn');

buttons.forEach((button) => {
  button.addEventListener('click', (e) => {
    const panelElement = e.target.nextSibling;
    const panelIsOpen = panelElement.classList.contains('open');

    buttons.forEach(andererButton) => {
      andererButton.nextElementSibling.classList.remove('open');
      andererButton.setAttribute('aria-expanded', 'false');
    });

    if (!panelIsOpen) {
      panelElement.classList.add('open');
      button.setAttribute('aria-expanded', 'true');
    }
  });
});
