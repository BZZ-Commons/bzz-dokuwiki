# Autor: Volkan Demir
# Desc: Umsetzung der ver- und entschlüsselung nach Cäsar
# Param1: v oder e
# Param2: Text zum Verschlüsseln oder entschlüsseln
# Offset: Länge des Offset als Ganzzahl
import sys

if (len(sys.argv) != 4):
   # Info, falls man nicht weis welche Parameter erwartet werden
   print("Aufruf: python [v|e] [klartext|chiffretext] offset")

#print ("Argumente", sys.argv)

modus = sys.argv[1]
text = sys.argv[2]
offset = int(sys.argv[3])
klartext = ""
chiffretext = ""

def verschluesseln(text, offset):
    ergebnis = ""
    for char in text:
        if char.islower():
            # 'a' = 97, 'z' = 122 -> mit Modulo bleibt es im Bereich a–z
            ergebnis += chr((ord(char) - 97 + offset) % 26 + 97)
        else:
            # Nicht-Kleinbuchstaben unverändert übernehmen
            ergebnis += char
    return ergebnis

def entschluesseln(text, offset):
    return verschluesseln(text, -offset)
    # entschluesseln ist verschlüsseln mit einem negativen offset

if modus == "v":
    chiffretext = verschluesseln(text, offset)
    print("Chiffretext: ", chiffretext)
else:   # hier braucht es keine Bedingung
    klartext = entschluesseln(text, offset)
    print("Klartext: ", klartext)




