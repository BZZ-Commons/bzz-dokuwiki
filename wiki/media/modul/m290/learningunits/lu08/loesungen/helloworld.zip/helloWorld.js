const greetings = ['Hello ', 'World!', 'Hello', 'Universe!'];

for (let i = 0; i < greetings.length; i++) {
  console.log(greetings[i]);
}
