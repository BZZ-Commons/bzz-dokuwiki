const express = require('express');
const mysql = require('mysql');

const app = express();
const PORT = 3000;

// Create connection to MySQL database
const db = mysql.createConnection({
    host: 'localhost',
    database: 'myDatabase',
    user: "restrictedUser",
    password: 'SafePassword123'
});

// Connect to the database
db.connect((err) => {
    if (err) {
        console.error('Database connection failed:', err);
        return;
    }
    console.log('Connected to MySQL database');
});

// Endpoint to get the system date from MySQL
app.get('/date', (req, res) => {
    db.query('SELECT NOW() AS system_date', (err, results) => {
        if (err) {
            console.error('Error fetching date:', err);
            res.status(500).send('Server error');
            return;
        }
        res.send(`Current system date and time: ${results[0].system_date}`);
    });
});

// Method to get data from the user table
app.get('/user', (req, res) => {
    const query = 'SELECT * FROM users'; // SQL query to select all rows from user table

    db.query(query, (err, results) => {
        if (err) {
            console.error('Error retrieving users:', err);
            res.status(500).send('Server error');
            return;
        }
        res.json(results); // Send the results as JSON
    });
});

app.get('/user/:id', (req, res) => {
    const userId = req.params.id;

    // SQL query to fetch user by id
    const query = 'SELECT * FROM users WHERE user_id = ?';

    db.query(query, [userId], (err, results) => {
        if (err) {
            console.error('Error fetching user:', err);
            res.status(500).send('Server error');
            return;
        }

        if (results.length === 0) {
            res.status(404).send('User not found');
        } else {
            res.status(200).json(results[0]);
        }
    });
});

// DELETE user method
app.delete('/user/:id', (req, res) => {
    const userId = req.params.id;

    const deleteQuery = 'DELETE FROM users WHERE user_id = ?';

    db.query(deleteQuery, [userId], (err, result) => {
        if (err) {
            res.status(500).send('Error deleting user');
        } else if (result.affectedRows === 0) {
            res.status(404).send('User not found');
        } else {
            res.send(`User with ID ${userId} deleted successfully`);
        }
    });
});

app.put('/user/:id', (req, res) => {
    const userId = req.params.id;
    const { username, email } = req.query; // Get username and email from query parameters

    // Ensure that at least one field is provided
    if (!username && !email) {
        return res.status(400).send('At least one field (username or email) must be provided for update.');
    }

    // Construct the update query
    const updateQuery = 'UPDATE users SET username = ?, email = ? WHERE user_id = ?';
    const values = [username || null, email || null, userId]; // Use null for any field not provided

    db.query(updateQuery, values, (err, result) => {
        if (err) {
            res.status(500).send('Error updating user');
        } else if (result.affectedRows === 0) {
            res.status(404).send('User not found');
        } else {
            res.send(`User with ID ${userId} updated successfully`);
        }
    });
});



// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
