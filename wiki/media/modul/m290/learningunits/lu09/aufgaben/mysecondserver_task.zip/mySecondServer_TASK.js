/* *******************************************************************************************
* Author: ?. ???, ??.??.????
* *******************************************************************************************
* Description:
* Express-Server, that displays the systemdate from the database.
** ***************************************************************************************** */
// Reference: www.npmjs.com/package/mysql

const mysql = require("???");   // Task1: import of the mysql-package
const express = require('???'); // Task2: import of the express-package/middleware

const port = 3000; // Kind of a telefon number, on which the server listens for requests

// Variable set with the db-connection credentials to connect the server to the database
const config = {
    host: 'localhost',
    database: '???', // Task3: Name of the database instance
    user: "???",     // Task4: Name of the user to access the database --> NOT root
    password: '???'  // Task5: Password of the user --> Not root-password
}

const connection = mysql.createConnection(config)
// connection line to the database, that takes the credentials
// and returns a open line to execute sql statements

// function that actually connects the server to the database
// result is successful or errormessage
connection.connect(function(err) {
    if (err) throw err;
    console.log('Connected to MySQL database:', connection.config.database);

    // Preparation of the sql statement, which will be send to the database
    var sqlstmt = 'SELECT ???'; // Task6: We want to display the systdate()

    connection.query(sqlstmt, function (err, result) {
        // the sqlstmt is send to the database
        if (err) throw err; // if everthing is fine, i receive the resultset
        console.table(???); // Task7: We can present the result as a table
    });
});





