/* *******************************************************************************************
* Author: V. Demir, 30.10.2024
* *******************************************************************************************
* Description:
* This is a basic web server, that display data in json format on the browser
** ***************************************************************************************** */
// Reference: www.npmjs.com/package/mysql

const http = require("http");
const req = require("express/lib/request"); // import of the http-package

const port = 3000; // Kind of a telefon number, on which the server listens for requests
const server =
    http.createServer(function(req, res) {
        res.setHeader('Content-Type', 'text/plain', 'application/json');
        res.setHeader('Access-Control-Allow-Origin', '*'); // We accept request from any browser
        res.writeHead(200); // status code: 200 = OK
        let dataObj = {id: 123, "name": "Bob", "email": "bob@terminator.com"};
        let data = JSON.stringify(dataObj); // JSOB-Object transfered to a string
        res.end(data);  // send the data to the browser
    });

server.listen(port, function() {
    console.log("Server started on port: " + port);
});
