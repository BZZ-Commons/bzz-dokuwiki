#!/bin/bash
$VMDIR="~/vmware/"

function usage() {
  echo "usage"
}

function changeConfig() {
  echo "changeConfig"
}

function renameCopy() {
  echo "renameCopy"
  changeConfig
}

function makeCopy() {
  echo "makeCopy"
  renameCopy
}

function main() {
  usage
  makeCopy
}

main
