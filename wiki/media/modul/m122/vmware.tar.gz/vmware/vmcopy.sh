#!/bin/bash
$BASEDIR="~/vmware/"

function usage() {
  echo "usage"
}

function changeConfig() {
  echo "changeConfig"
}

function renameCopy() {
  echo "renameCopy"
  changeConfig
}

function userCopy() {
  echo "userCopy"
  renameCopy
}

function main() {
  usage
  userCopy
}

main
