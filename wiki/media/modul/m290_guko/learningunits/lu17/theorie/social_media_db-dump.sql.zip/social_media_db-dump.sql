-- MySQL dump 10.13  Distrib 9.4.0, for macos15 (arm64)
--
-- Host: 127.0.0.1    Database: social_media
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `posts`
--

CREATE DATABASE IF NOT EXISTS social_media;
USE social_media;

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `posts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image_url` varchar(512) DEFAULT NULL,
  `description` text,
  `likes` int DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,1,'Sunset Vibes','https://picsum.photos/800/450?random=1','Caught this beautiful sunset today! Nature never disappoints.',12,'2025-12-01 23:50:36','2025-12-13 00:53:03'),(3,3,'Weekend Adventure','https://picsum.photos/800/450?random=3','Explored new hiking trails this weekend! Loved every moment.',22,'2025-03-01 23:50:36','2025-12-13 00:53:03'),(4,4,'Throwback Memories','https://picsum.photos/800/450?random=4','Found this old picture in my gallery. Still one of my favorites.',18,'2025-11-25 23:50:36','2025-12-13 00:53:03'),(5,5,'City Lights','https://picsum.photos/800/450?random=5','The city at night is a whole different vibe.',33,'2025-08-16 22:50:36','2025-12-13 00:53:03'),(6,6,'Homemade Dinner','https://picsum.photos/800/450?random=6','Tried cooking something new today. Surprisingly delicious!',7,'2025-10-25 22:50:36','2025-12-13 00:53:03'),(7,7,'My Workspace Today','https://picsum.photos/800/450?random=7','Keeping things minimal and productive.',14,'2025-10-18 22:50:36','2025-12-13 00:53:03'),(8,8,'Chilling at the Park','https://picsum.photos/800/450?random=8','Perfect weather to relax outside.',9,'2025-12-07 23:50:36','2025-12-13 00:53:03'),(9,9,'Fitness Motivation','https://picsum.photos/800/450?random=9','Stay consistent, even on tough days!',27,'2025-05-04 22:50:36','2025-12-13 00:53:03'),(10,10,'Reading Time','https://picsum.photos/800/450?random=10','Started a new book today. Can’t stop reading!',11,'2025-12-03 23:50:36','2025-12-13 00:53:03'),(11,3,'Ocean Breeze','https://picsum.photos/800/450?random=11','Missing the beach already...',30,'2025-12-01 23:50:36','2025-12-13 00:53:03'),(12,7,'Coding All Night','https://picsum.photos/800/450?random=12','When the code finally works at 3 AM!',41,'2025-11-30 23:50:36','2025-12-13 00:53:03'),(13,2,'Road Trip!','https://picsum.photos/800/450?random=13','Spontaneous trips are the best trips.',16,'2025-09-25 22:50:36','2025-12-13 00:53:03'),(14,1,'New Art Project','https://picsum.photos/800/450?random=14','Testing out some new brushes and color palettes.',22,'2025-02-08 23:50:36','2025-12-13 00:53:03'),(15,5,'Café Afternoon','https://picsum.photos/800/450?random=15','A warm drink and good company.',19,'2025-11-02 23:50:36','2025-12-13 00:53:03'),(16,1,'Morning Coffee','https://picsum.photos/800/450?random=50','Nothing beats starting the day with a warm cup of coffee.',0,'2025-12-13 11:36:38','2025-12-13 12:36:38'),(17,2,'Evening Break','https://picsum.photos/800/450?random=46','Nothing beats ending the day with a drink.',0,'2025-12-13 11:47:49','2025-12-13 12:47:49'),(18,3,'Coding with the folks from the BZZ.','https://picsum.photos/800/450?random=161','Gerade mit Postman erstellt! Hi!',0,'2025-12-15 09:03:47','2025-12-15 10:03:47');
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `birthday` date DEFAULT NULL,
  `profile_img_url` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Doe','John','john.doe@example.com','1978-04-18','https://avatar.iran.liara.run/public/1'),(2,'Smith','Jane','jane.smith@example.com','1981-10-23','https://avatar.iran.liara.run/public/2'),(3,'Johnson','Alice','alice.johnson@example.com','1975-10-05','https://avatar.iran.liara.run/public/3'),(4,'Brown','Bob','bob.brown@example.com','1973-02-14','https://avatar.iran.liara.run/public/4'),(5,'Davis','Charlie','charlie.davis@example.com','1977-07-07','https://avatar.iran.liara.run/public/5'),(6,'White','Eve','eve.white@example.com','1976-09-07','https://avatar.iran.liara.run/public/6'),(7,'Black','Frank','frank.black@example.com','1993-05-08','https://avatar.iran.liara.run/public/7'),(8,'Green','Grace','grace.green@example.com','1993-07-13','https://avatar.iran.liara.run/public/8'),(9,'Blue','Hank','hank.blue@example.com','1990-12-08','https://avatar.iran.liara.run/public/9'),(10,'Yellow','Ivy','ivy.yellow@example.com','1976-01-07','https://avatar.iran.liara.run/public/10');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-02  0:47:01
